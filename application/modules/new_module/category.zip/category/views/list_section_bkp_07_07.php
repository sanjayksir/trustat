<?php  //echo '<pre>';print_r($listingData);exit; ?>
<div class="col-xs-12">
       <table id="" class="table-striped table-bordered table-hover">
        <thead>
          <tr>
            <th>Menu Name</th>
             <th style="text-align:center;" >Action</th>
           </tr>
        </thead>
        <tbody id="table_data_div" class="tree_menu">
          <?php   foreach($listingData as $val){   ?>
          <tr id="show<?php echo $val['id'];?>">
            <td><strong><?php echo $val['menu']; ?></strong>
            	<div style="margin-top:10px;"><?php 
				##============== get Child ====================##
				$child_arr = getChildFromParent($val['id']);
				if($child_arr>0){
					foreach($child_arr as $chids){
						echo '<div class="tree_menu_child"><i class="fa fa-angle-double-right" aria-hidden="true"></i> '.$chids['menu'].'&nbsp;&nbsp;&nbsp;
						&nbsp;<div style="float:right;"><a href="'.base_url().'myspidey_user_group_permissions/edit_child_menu/'.$chids['id'].'"><i class="ace-icon fa fa-pencil"></i></a> </div>'.'</div>';
					}
				}
				##============== get Child ====================##
				?>
                </div>
             </td>
                <td align="center">  <a class="green" href="#" onClick="edit_menu(<?php echo $val['id'];?>);" title="Edit Menu"><i class="ace-icon fa fa-pencil bigger-130"></i> </a> &nbsp;<a href="<?php echo base_url(); ?>myspidey_user_group_permissions/get_child_menu/<?php echo $val['id'];?>" class="tooltip-success" data-rel="tooltip" title="Add Child Menu"><i class="fa fa-plus-square bigger-120" aria-hidden="true"></i></a></td>
          </tr>
          <?php } ?>
        </tbody>
      </table>
 
</div>
<script>
function edit_menu(id){
 	window.location.href="<?php echo base_url(); ?>myspidey_user_group_permissions/get_edit_section/"+id;
 }
</script>
