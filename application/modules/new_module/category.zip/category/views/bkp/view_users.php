<?php //echo '<pre>kam==';print_r($users);exit;?>
<div>
<ul>
<?php if(count($users)>0){
    		foreach($users as $val){
?>
    		<li><?php echo ucfirst($val['user_name']);?>&nbsp;&nbsp;<a href="<?php echo base_url().'myspidey_user_group_permissions/myspidey_user_master/edit_user/'.$val['user_id'];?>">Edit</a></li>
<?php 			}
      }else{
	  ?>
      <li>No User</li>
 <?php }?>
</ul>
</div>